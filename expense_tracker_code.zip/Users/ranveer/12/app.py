from flask import Flask, render_template, request, redirect, url_for, flash
from database import init_db
from models.expense import Expense
from models.tracker import ExpenseTracker
from models.fetcher import OnlinePaymentFetcher
from models.scanner import ReceiptScanner
from datetime import datetime
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'super_secret_key_for_flash_messages'

# Initialize DB on startup
init_db()

tracker = ExpenseTracker()
fetcher = OnlinePaymentFetcher()
scanner = ReceiptScanner()

BUDGET_LIMIT = 10000.0
CURRENCY = "₹"

@app.context_processor
def inject_globals():
    return {'currency': CURRENCY}

@app.route('/')
def index():
    # Get current month's expenses
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    total_monthly = tracker.get_total_expenses(year=current_year, month=current_month)
    recent_expenses = tracker.get_all_expenses()[:5]  # Get top 5 recent
    
    budget_warning = total_monthly > BUDGET_LIMIT
    
    return render_template('index.html', 
                           total_monthly=total_monthly, 
                           recent_expenses=recent_expenses,
                           budget_limit=BUDGET_LIMIT,
                           budget_warning=budget_warning)

@app.route('/add', methods=['GET', 'POST'])
def add_expense():
    if request.method == 'POST':
        amount = float(request.form['amount'])
        category = request.form['category']
        source = request.form['source']
        date = request.form['date']
        description = request.form['description']
        
        expense = Expense(amount=amount, category=category, payment_source=source, date=date, description=description)
        tracker.add_expense(expense)
        flash('Expense added successfully!', 'success')
        return redirect(url_for('index'))
        
    prefill_amount = request.args.get('amount', '')
    prefill_date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    prefill_desc = request.args.get('description', '')
    return render_template('add_expense.html', amount=prefill_amount, date=prefill_date, description=prefill_desc)

@app.route('/scan', methods=['GET', 'POST'])
def scan_receipt():
    if request.method == 'POST':
        if 'receipt' not in request.files:
            flash('No file uploaded', 'danger')
            return redirect(request.url)
            
        file = request.files['receipt']
        if file.filename == '':
            flash('No file selected', 'danger')
            return redirect(request.url)
            
        if file:
            filename = secure_filename(file.filename)
            os.makedirs('temp', exist_ok=True)
            filepath = os.path.join('temp', filename)
            file.save(filepath)
            
            try:
                result = scanner.scan_image(filepath)
                flash('Receipt scanned successfully! Please review the details.', 'success')
                if os.path.exists(filepath):
                    os.remove(filepath)
                return redirect(url_for('add_expense', 
                                        amount=result.get('amount', ''), 
                                        date=result.get('date', ''), 
                                        description=result.get('description', '')))
            except Exception as e:
                flash(f'Error scanning receipt: {str(e)}', 'danger')
                return redirect(request.url)
                
    return render_template('scan.html')

@app.route('/reports')
def reports():
    all_expenses = tracker.get_all_expenses()
    category_breakdown = tracker.get_category_breakdown()
    
    # Prepare data for Chart.js
    labels = list(category_breakdown.keys())
    data = list(category_breakdown.values())
    
    return render_template('reports.html', expenses=all_expenses, labels=labels, data=data)

@app.route('/import', methods=['GET', 'POST'])
def import_payments():
    if request.method == 'POST':
        # Simulate receiving a single payment notification right now
        new_expense = fetcher.fetch_new_transaction()
        tracker.add_expense(new_expense)
        flash(f'New payment of {CURRENCY}{new_expense.amount} from {new_expense.payment_source} has been auto-synced!', 'success')
        return redirect(url_for('index'))
        
    return render_template('import.html')

if __name__ == '__main__':
    app.run(debug=True)
