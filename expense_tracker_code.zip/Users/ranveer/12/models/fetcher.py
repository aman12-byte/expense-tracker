import random
from datetime import datetime
from models.expense import Expense

class OnlinePaymentFetcher:
    def __init__(self):
        self.payment_sources = ["Google Pay", "PhonePe", "Paytm"]
        self.categories = ["Food", "Transport", "Shopping", "Entertainment", "Utilities", "Groceries"]

    def fetch_new_transaction(self):
        """Simulates receiving a real-time payment notification from an app."""
        amount = round(random.uniform(50.0, 1500.0), 2)
        category = random.choice(self.categories)
        source = random.choice(self.payment_sources)
        date = datetime.now().strftime('%Y-%m-%d') # Happens today
        description = f"Live sync from {source}"
        
        return Expense(amount=amount, category=category, payment_source=source, date=date, description=description)
