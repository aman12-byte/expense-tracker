class Expense:
    def __init__(self, amount, category, payment_source, date, description="", id=None):
        self.id = id
        self.amount = amount
        self.category = category
        self.payment_source = payment_source
        self.date = date
        self.description = description

    def __repr__(self):
        return f"<Expense(id={self.id}, amount={self.amount}, category='{self.category}', source='{self.payment_source}', date='{self.date}')>"
