import sqlite3
from models.expense import Expense
from database import DB_NAME
from collections import defaultdict

class ExpenseTracker:
    def __init__(self):
        self.db_name = DB_NAME

    def _get_connection(self):
        return sqlite3.connect(self.db_name)

    def add_expense(self, expense: Expense):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO expenses (amount, category, payment_source, date, description)
            VALUES (?, ?, ?, ?, ?)
        ''', (expense.amount, expense.category, expense.payment_source, expense.date, expense.description))
        conn.commit()
        conn.close()

    def get_all_expenses(self):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id, amount, category, payment_source, date, description FROM expenses ORDER BY date DESC')
        rows = cursor.fetchall()
        conn.close()
        
        expenses = []
        for row in rows:
            expenses.append(Expense(
                id=row[0], amount=row[1], category=row[2], 
                payment_source=row[3], date=row[4], description=row[5]
            ))
        return expenses

    def get_total_expenses(self, year=None, month=None):
        expenses = self.get_all_expenses()
        total = 0.0
        for exp in expenses:
            # Simple date filtering based on YYYY-MM-DD format
            if year and not exp.date.startswith(str(year)):
                continue
            if month and not exp.date.split('-')[1] == str(month).zfill(2):
                continue
            total += exp.amount
        return total

    def get_category_breakdown(self, year=None, month=None):
        expenses = self.get_all_expenses()
        breakdown = defaultdict(float)
        for exp in expenses:
            if year and not exp.date.startswith(str(year)):
                continue
            if month and not exp.date.split('-')[1] == str(month).zfill(2):
                continue
            breakdown[exp.category] += exp.amount
        return dict(breakdown)
