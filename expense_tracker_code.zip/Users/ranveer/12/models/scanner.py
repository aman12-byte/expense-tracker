import pytesseract
from PIL import Image
import re
from datetime import datetime

class ReceiptScanner:
    def scan_image(self, image_path):
        """
        Attempt to scan an image using Tesseract OCR.
        If Tesseract is not installed, it falls back to a mock OCR for demonstration.
        """
        try:
            # Try real OCR
            img = Image.open(image_path)
            text = pytesseract.image_to_string(img)
            return self.parse_text(text)
        except Exception as e:
            # Fallback for College Mini Project if tesseract is not installed
            print(f"OCR Failed or Tesseract not installed. Falling back to mock. Error: {e}")
            return self.mock_scan()

    def parse_text(self, text):
        """Parse raw text to extract date and amount"""
        amount = 0.0
        date = datetime.now().strftime('%Y-%m-%d')
        
        # Look for typical Total patterns
        # Find all decimal numbers
        amounts = re.findall(r'\b\d+\.\d{2}\b', text)
        if amounts:
            # Usually the total is the largest number on the receipt
            amount = max([float(a) for a in amounts])
        
        # Look for dates
        date_match = re.search(r'\b(\d{2}[-/]\d{2}[-/]\d{4}|\d{4}[-/]\d{2}[-/]\d{2})\b', text)
        if date_match:
            try:
                date_str = date_match.group(1).replace('/', '-')
                if len(date_str.split('-')[0]) == 4:
                    date = datetime.strptime(date_str, '%Y-%m-%d').strftime('%Y-%m-%d')
                else:
                    date = datetime.strptime(date_str, '%d-%m-%Y').strftime('%Y-%m-%d')
            except ValueError:
                pass
                
        return {
            'amount': amount,
            'date': date,
            'description': 'Scanned Receipt',
            'raw_text': text
        }

    def mock_scan(self):
        """Simulate scanning for demonstration purposes"""
        return {
            'amount': 250.75,
            'date': datetime.now().strftime('%Y-%m-%d'),
            'description': 'Lunch at Cafe (Mock Scan)',
            'raw_text': 'Mock Receipt Data\nTotal: 250.75\nThank you!'
        }
